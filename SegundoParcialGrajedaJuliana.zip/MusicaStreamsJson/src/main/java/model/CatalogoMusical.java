package model;

import repository.CSVSerializable;
import java.io. *;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;


public class CatalogoMusical<T extends CSVSerializable & Serializable>{
    private List<T> objetos;
    

    public CatalogoMusical() {
        this.objetos = new ArrayList<>();
    }
    
    public void agregar(T objeto){ objetos.add(objeto);}
    public T obtener(int indice){ return objetos.get(indice);}
    public T eliminar(int indice){ return objetos.remove(indice);}
    
    public List<T> filtrar(Predicate<T> criterio){
        // Creamos una lista donde guardaremos los objetos filtrados
        List<T> filtrados = new ArrayList<>();
        // recorremos la lista original elemento por elemento
        //si el criterio iguala el elemento entonces true
        // agregamos el elemento a la nueva lista
        
        for(T elemento : objetos) if (criterio.test(elemento)) filtrados.add(elemento);
        //retornamos la nueva lista con los elementos filtrados    
        return filtrados;
    }
    
    public void ordenar(){
        // Verificamos que la lista no este vacia y que el objeto instancie
        // comparable para que  no se genere un error
        if (!(objetos.isEmpty()) && objetos.get(0) instanceof Comparable){
            //Utilizamos una lambda para ordenar a y b
            // siendo a casteada a comparable<T>
            objetos.sort((a, b) -> ((Comparable<T>) a).compareTo(b));
        }
        else{
            //CASO CONTRARIO tiramos un error de Estado ilegal
            throw new IllegalStateException("Los elementos no implementan Comparable... ");
        }

    }
    
    public void ordenar(Comparator<T> comparador){
        objetos.sort(comparador);
    }
    
    public void paraCadaElemento(Consumer<T> accion){
        //For each recorre toda la lista y ejecuta la accion de un solo argumento
        // para cada objeto de la lista.
        objetos.forEach(accion);
    }
    
    // Convertimos objetos en un archivo binario
    public void guardarEnArchivo(String ruta) throws IOException{
        
        // Usamos try-with-resources que cierra autamaticamente los recursos
        // Creamos o sobrescribimos un archivo con FileOutputStream
        // Escribimos objetos completos con ObjectOutputStream.
        try (ObjectOutputStream canal = new ObjectOutputStream(new FileOutputStream(ruta))) {
            // Escribimos el contenido de la lista de objetos en el archivo
            // Se debe implementar Serializable para utilizarlo
            canal.writeObject(objetos);
        }
    }
    
    // Convertimos archivos binarios en objetos nuevamente.
    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException{
        
        //Usamos try-with-resources 
        // Abrimos el archivo binario con FileInputStream
        // Convertimos secuencias de Byte en objetos reales
        try (ObjectInputStream canal = new ObjectInputStream(new FileInputStream(ruta))){
            //Con readObject recuperamos el objeto serializado guardado previamente
            // El (List<T>) es un casteo ya que readObject devuelve un objeto
            // genérico
            objetos = (List<T>)canal.readObject();
        }
    }
    
    public void guardarEnCSV(String ruta) throws IOException{
        // Usamos un try-with-resource
        // Creamos un archivo escritor
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))){
            // Recorremos cada objeto lo escribimos en el csv con un salto de renglón
            for(T objeto : objetos){
                escritor.write(objeto.toCSV());
                escritor.newLine();
            }
        }
    }
    
    public void cargarDesdeCSV(String ruta, Function<String, T> creador) throws IOException{
        //Limpiamos la lista de objetos para que no se dupliquen
            objetos.clear();
        // Abrimos un BufferedReader para leer linea por linea
        // Le pasamos un archivo que leer con FileReader
        try(BufferedReader lector = new BufferedReader(new FileReader(ruta))){
            // Creamos una variable para guardar cada linea
            String linea;
            // miestras que la linea sea distinta de null agregamos esa linea
            // a la lista de objetos dandole el formato String o T
            while ((linea = lector.readLine()) != null){
                objetos.add(creador.apply(linea));
            }
        }
    }
    
}
