
package model;

import java.io.Serializable;
import repository.CSVSerializable;
import repository.GeneroMusical;

public class Cancion implements CSVSerializable, Comparable<Cancion>, Serializable{
    private int id;
    private String titulo;
    private String artista;
    private GeneroMusical genero;

    public Cancion(int id, String titulo, String artista, GeneroMusical genero) {
        this.id = id;
        this.titulo = titulo;
        this.artista = artista;
        this.genero = genero;
    }
    
    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }
    
    @Override
    // Si queremos que vaya en orden descendente primero ponemos el que pasamos
    // por parametro y luego el propio.
    public int compareTo(Cancion otraCancion) {
        return Integer.compare(otraCancion.id, this.id);
        //FORMA ASCENDENTE
        //return Integer.compare(this.id, otraCancion.id);
        
    }

    @Override
    // Para pasar a csv es simplemente poner comas entre cada variable
    public String toCSV() {
        return id + "," + titulo + "," + artista + "," + genero;
    }
    

    //Practicar from csv
    public static Cancion fromCSV(String texto) {
        //Split separa por un determinado caracter y encierra el resto en comillas
        // Y el String[] lo convierte en una lista
        String[] partes = texto.split(",", -1);
        //Parsea el contenido del indice 0 dentro de partes
        // Obtiene cada una de las variables en el resto de indices
        // Value of trae el valor dentro del enum, siendo lo que se encuentra
        // en el indice numerp 3 de la lista partes
        //retorna un nuevo Objeto Cancion
        return new Cancion(
                Integer.parseInt(partes[0]),
                partes[1],
                partes[2],
                GeneroMusical.valueOf(partes[3])
        );
    }

    @Override
    public String toString() {
        return "[" + id + "] " + titulo + " - " + artista + " (" + genero + ')';
    }

}
