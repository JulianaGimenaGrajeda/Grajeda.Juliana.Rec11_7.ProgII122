
package repository;

public enum GeneroMusical {
    ROCK,
    POP,
    JAZZ,
    CLASICA,
    ELECTRONICA,
    REGGAETON
}
