
package Main;


import config.Ruta;
import java.io.IOException;
import model.Cancion;
import model.CatalogoMusical;
import repository.GeneroMusical;

public class Main {
    public static void main(String[] args) {
        try {
            CatalogoMusical<Cancion> catalogo = new CatalogoMusical<>();

            catalogo.agregar(new Cancion(1, "Love of my life", "Queen", GeneroMusical.ROCK));
            catalogo.agregar(new Cancion(2, "Billie Jean", "Michael Jackson", GeneroMusical.POP));
            catalogo.agregar(new Cancion(3, "Shape of You", "Ed Sheeran", GeneroMusical.POP));
            catalogo.agregar(new Cancion(4, "Take Five", "Dave Brubeck", GeneroMusical.JAZZ));
            catalogo.agregar(new Cancion(5, "Canon in D", "Pachelbel", GeneroMusical.CLASICA));

            System.out.println("Catálogo de canciones:");
            catalogo.paraCadaElemento(c -> System.out.println(c));

            //FILTRAR GENERO POR POP
            System.out.println("\nCanciones de género POP:");
            catalogo.filtrar(c -> c.getGenero() == GeneroMusical.POP)
                    .forEach(c -> System.out.println(c));
            
            //FILTRAR GENERO POR JAZZ
            System.out.println("\nCanciones de género JAZZ:");
            catalogo.filtrar(c -> c.getGenero() == GeneroMusical.JAZZ)
                    .forEach(c -> System.out.println(c));

            //FILTRAR SI CONTIENE SHAPE
            System.out.println("\nCanciones cuyo título contiene 'shape':");
            catalogo.filtrar(c -> c.getTitulo().toLowerCase().contains("shape"))
                    .forEach(c -> System.out.println(c));
            
            //FILTRAR SI CONTIENE LOVE
            System.out.println("\nCanciones cuyo título contiene 'love':");
            catalogo.filtrar(c -> c.getTitulo().toLowerCase().contains("love"))
                    .forEach(c -> System.out.println(c));

            System.out.println("\nCanciones ordenadas por ID:");
            catalogo.ordenar();
            catalogo.paraCadaElemento(c -> System.out.println(c));

            System.out.println("\nCanciones ordenadas por artista:");
            catalogo.ordenar((a, b) -> a.getArtista().compareToIgnoreCase(b.getArtista()));
            catalogo.paraCadaElemento(c -> System.out.println(c));

            catalogo.guardarEnArchivo(Ruta.BINARIO);

            CatalogoMusical<Cancion> cargado = new CatalogoMusical<>();
            cargado.cargarDesdeArchivo(Ruta.BINARIO);
            System.out.println("\nCanciones cargadas desde binario:");
            cargado.paraCadaElemento(c -> System.out.println(c));

            catalogo.guardarEnCSV(Ruta.CSV);
            cargado.cargarDesdeCSV(Ruta.CSV,linea -> Cancion.fromCSV(linea));
            System.out.println("\nCanciones cargadas desde CSV:");
            cargado.paraCadaElemento(c -> System.out.println(c));

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}

