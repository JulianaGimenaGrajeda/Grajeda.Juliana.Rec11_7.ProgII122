
package config;


public class Ruta {
    public static final String BINARIO = "src/main/java/data/canciones.dat";
    public static final String CSV = "src/main/java/data/canciones.csv";
}
