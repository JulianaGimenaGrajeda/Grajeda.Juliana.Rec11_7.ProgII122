
package repository;


public enum GeneroMusical {
    ROCK,
    JAZZ,
    POP,
    CLASICA,
    ELECTRONICA,
}