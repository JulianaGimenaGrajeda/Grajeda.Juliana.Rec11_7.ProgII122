
package repository;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Gestionable<T>{
    
    void agregar(T objeto);
    T obtener(int indice);
    T eliminar(int indice);
    void limpiarElementos();
    
    List<T> filtrar(Predicate<T> criterio);
    
    void ordenar();
    void ordenar(Comparator<T> comparador);
    
    void guardarEnBinario(String ruta) throws IOException;
    void cargarDesdeBinario(String ruta)throws IOException, ClassNotFoundException;
    
    void guardarEnCSV(String ruta) throws IOException;
    void cargarDesdeCSV(String ruta, Function<String, T> creador)throws IOException, ClassNotFoundException;
    
    void mostrarTodo();
}