
package config;

public class AppConfig {
    public static final String PATH_SER = "src/main/java/resources/eventos.dat";
    public static final String PATH_CSV = "src/main/java/resources/eventos.csv";
    public static final String PATH_JSON = "src/main/java/resources/eventos.json";
}
