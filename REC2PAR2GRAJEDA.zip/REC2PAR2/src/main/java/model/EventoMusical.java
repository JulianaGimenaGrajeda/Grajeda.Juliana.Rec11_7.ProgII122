
package model;

import repository.CSVSerializable;
import java.io.Serializable;
import java.time.LocalDate;
import repository.GeneroMusical;


public class EventoMusical extends Evento implements Comparable<EventoMusical>, CSVSerializable, Serializable{
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    @Override
    public int compareTo(EventoMusical otra) {
        return this.getFecha().compareTo(otra.getFecha());//orden natural
    }

    @Override
    public String toCSV() {
        return getId() + "," + getNombre() + "," + getFecha() + "," + artista + "," + genero;
    }
    
    @Override
    public String toHeaderCSV(){
        return "id,nombre,fecha,artista,genero";
    }  
    
    public static EventoMusical fromCSV(String linea) {
        String[] partes = linea.split(",");
        
        int id = Integer.parseInt(partes[0].trim());
        String nombre = partes[1];
        LocalDate fecha = LocalDate.parse(partes[2]);
        String artista = partes[3];
        GeneroMusical genero = GeneroMusical.valueOf(partes[4].toUpperCase());

        return new EventoMusical(id, nombre, fecha, artista, genero);
    }

    @Override
    public String toString() {
        return super.toString() + "Evento Musical: "+ artista + "(" + genero + ')';
    }
    
    
}
