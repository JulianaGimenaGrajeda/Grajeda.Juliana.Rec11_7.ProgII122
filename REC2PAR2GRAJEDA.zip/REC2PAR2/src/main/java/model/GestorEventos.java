
package model;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import repository.CSVSerializable;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import repository.Gestionable;

public class GestorEventos<T extends CSVSerializable & Serializable> implements Gestionable<T>{
    private List<T> eventos;

    public GestorEventos() {
        this.eventos = new ArrayList<>();
    }

    @Override
    public void agregar(T objeto) {
        eventos.add(objeto);
    }

    @Override
    public T obtener(int indice) {
        return eventos.get(indice);
    }
    
    @Override
    public T eliminar(int indice) {
        return eventos.remove(indice);
    }

    @Override
    public void limpiarElementos() {
        eventos.clear();
    }
    
    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        
        List<T> filtrados = new ArrayList<>();
        for (T e : eventos) if (criterio.test(e)) filtrados.add(e);
        return filtrados;
    }

    @Override
    public void ordenar() {
        if (!(eventos.isEmpty()) && eventos.get(0) instanceof Comparable){
            eventos.sort((a,b) -> ((Comparable<T>)a).compareTo(b));
        }
        else{
            throw new IllegalStateException("El elemento no es instancia de Comparable.. ");
        }
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        eventos.sort(comparador);
    }

    @Override
    public void guardarEnBinario(String ruta) throws IOException {
        try(ObjectOutputStream canal = new ObjectOutputStream(new FileOutputStream(ruta))){
            canal.writeObject(eventos);
        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws IOException, ClassNotFoundException {
        try(ObjectInputStream canal = new ObjectInputStream(new FileInputStream(ruta))){
            eventos = (List<T>) canal.readObject();
        }
    }

    @Override
    public void guardarEnCSV(String ruta) throws IOException {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            if (!eventos.isEmpty()) {
                escritor.write(eventos.get(0).toHeaderCSV());
                escritor.newLine();

                for (T e : eventos) {
                    escritor.write(e.toCSV());
                    escritor.newLine();
                }
            }
        }
    }
    
    //Guardar en archivo JSON
    public void guardarEnJSON(String ruta) throws IOException{
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try(FileWriter escritor = new FileWriter(ruta)){
            gson.toJson(eventos, escritor);
        }
    }
    
    //Cargar en JSON
    public void cargarDesdeJSON(String ruta) throws IOException{
        Gson gson = new Gson();
        try(FileReader lector = new FileReader(ruta)){
            Type tipoLista = new TypeToken<List<T>>(){}.getType();
            eventos = gson.fromJson(lector, tipoLista);
        }
    }
    
    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> creador) throws IOException, ClassNotFoundException {
        limpiarElementos();
        
        try(BufferedReader lector = new BufferedReader(new FileReader(ruta))){
            String linea = lector.readLine();
            
            while((linea = lector.readLine()) != null){
                eventos.add(creador.apply(linea));
       
            }
            
        }
    }

    @Override
    public void mostrarTodo() {
        eventos.forEach(System.out::println);
    }

    
}
